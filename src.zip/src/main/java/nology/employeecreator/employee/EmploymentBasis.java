package nology.employeecreator.employee;

public enum EmploymentBasis {
    FULL_TIME,PART_TIME
}
