package nology.employeecreator.employee;

public enum EmployeeRole {
    ADMIN,
    HR,
    MANAGER,
    EMPLOYEE,
    INTERN,
    CONTRACTOR
}
