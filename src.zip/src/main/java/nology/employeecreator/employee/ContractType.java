package nology.employeecreator.employee;

public enum ContractType {
    PERMANENT, CONTRACT
}
